﻿Public Class Form1
    '声明初始变量
    Dim tbl As Boolean = False                                                  '定义文本框默认文本是否清除，初始值否
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        '窗体初始化
        Me.skeg.SkinFile = "Resource/Skin/MacOS.ssk"                            '加载窗体皮肤
        Me.Icon = New Icon("Resource/icon/logo.ico", 32, 32)                    '加载窗体图标

        FileOpen(1, "Resource/Text/form1.text", OpenMode.Input)
        Me.Text = LineInput(1)
        FileClose()
        FileOpen(2， "Resource/Text/form1/label1.text", OpenMode.Input)
        Me.Label1.Text = LineInput(2)
        FileClose()
        FileOpen(3, "Resource/Text/form1/button1.text", OpenMode.Input)
        Button1.Text = LineInput(3)
        FileClose()
        '加载背景图片
        Me.BackgroundImage = System.Drawing.Image.FromFile("Resource/img/backgroundimg.jpg")
        Me.BackgroundImageLayout = ImageLayout.Stretch

        '加载音乐
        My.Computer.Audio.Play("Resource/Audio/music.wav", AudioPlayMode.Background)
        Me.MaximizeBox = False

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If tbl = False Or TextBox1.Text = "" Then
            MsgBox("未输入任何内容，请在文本框内输入答案",, " 温馨提示")
            TextBox1.ForeColor = Color.Red
        Else
            Dim answer As String = ""
            FileOpen(4, "Setting/answer.text", OpenMode.Input)
            answer = LineInput(4)
            FileClose()
            If answer = TextBox1.Text Then
                Form2.Show()
                My.Computer.Audio.Stop()
                Me.Hide()
            Else
                MsgBox("很遗憾，回答错误",, "抱歉")
                TextBox1.ForeColor = Color.Red

            End If
        End If

    End Sub

    Private Sub TextBox1_Click(sender As Object, e As EventArgs) Handles TextBox1.Click
        If tbl = False Then
            TextBox1.Text = ""
            tbl = True
            TextBox1.ForeColor = Color.Black

        End If
    End Sub

    Private Sub TextBox1_DoubleClick(sender As Object, e As EventArgs) Handles TextBox1.DoubleClick
        TextBox1.Text = ""
        TextBox1.ForeColor = Color.Black

    End Sub

    Private Sub ToolTip1_Popup(sender As Object, e As PopupEventArgs)

    End Sub
End Class

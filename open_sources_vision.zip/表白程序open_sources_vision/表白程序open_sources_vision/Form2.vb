﻿Public Class Form2
    Dim pl As Boolean = False
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.skeg.SkinFile = "Resource/Skin/MacOS.ssk"                            '加载窗体皮肤
        Me.Icon = New Icon("Resource/icon/logo.ico", 32, 32)                    '加载窗体图标
        AxWindowsMediaPlayer1.URL = "Resource/Video/demo.mp4"
        FileOpen(1, "Resource/Text/form2.text", OpenMode.Input)
        Me.Text = LineInput(1)
        FileClose()
    End Sub
End Class